export { default } from "./gate";
